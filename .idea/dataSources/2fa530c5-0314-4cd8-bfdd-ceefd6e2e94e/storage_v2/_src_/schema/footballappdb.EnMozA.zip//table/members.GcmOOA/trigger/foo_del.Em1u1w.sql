create definer = root@`%` trigger foo_del
    before delete
    on members
    for each row
    IF OLD.Type <=> 'SystemManger' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot delete System Manger';
    END IF;

